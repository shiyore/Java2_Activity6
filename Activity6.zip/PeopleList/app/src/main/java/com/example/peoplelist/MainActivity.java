package com.example.peoplelist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {

    Button b_add , b_sortABC , b_sortAge;
    ListView lv_people;

    PersonAdapter adapter;
    MyFriends myFriends;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myFriends = ((MyApplication) this.getApplication()).getMyFriends();
        b_add = findViewById(R.id.b_add);
        b_sortABC = findViewById(R.id.b_sortABC);
        b_sortAge = findViewById(R.id.b_sortAge);
        lv_people = findViewById(R.id.lv_people);



        adapter = new PersonAdapter(MainActivity.this, myFriends);

        lv_people.setAdapter(adapter);

        //get info from the personForm
        Bundle incomingMessages = getIntent().getExtras();
        String name;
        int age , picnumber;
        if(incomingMessages != null){
            name = incomingMessages.getString("name");
            age = Integer.parseInt(incomingMessages.getString("age"));
            picnumber = Integer.parseInt(incomingMessages.getString("pic"));
            int positionToEdit = incomingMessages.getInt("edit");

            //create person
            Person p = new Person(name , age , picnumber);

            //add the person to the list
            if(positionToEdit > -1){
                myFriends.getMyFriendsList().remove(positionToEdit);
            }
            myFriends.getMyFriendsList().add(p);
            adapter.notifyDataSetChanged();

        }



        b_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(),newPersonForm.class);
                startActivity(i);
            }
        });

        b_sortABC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Collections.sort(myFriends.getMyFriendsList());
                adapter.notifyDataSetChanged();
            }
        });
        b_sortAge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Collections.sort(myFriends.getMyFriendsList(), new Comparator<Person>() {
                    @Override
                    public int compare(Person o1, Person o2) {
                        return o1.getAge() - o2.getAge();
                    }

                });
                adapter.notifyDataSetChanged();
            }
        });
        lv_people.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                editPerson(position);
            }
        });

    }
    public void editPerson(int position){
        Intent i =  new Intent(getApplicationContext() , newPersonForm.class);

        //get the context of the person
        Person p = myFriends.getMyFriendsList().get(position);
        i.putExtra("edit" , position);
        i.putExtra("name", p.getName());
        i.putExtra("age" , p.getAge());
        i.putExtra("pic" , p.getPicnumber());

        startActivity(i);
    }
}
